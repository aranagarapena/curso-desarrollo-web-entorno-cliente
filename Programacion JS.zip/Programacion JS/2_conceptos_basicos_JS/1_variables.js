'use strict'

// ------------- PASOS ------------------------

// Objetivo: aprender lo basico respecto a las variables en JS

// Para iniciarnos en JavaScript
// 1 - Mirar Curso en W3School - https://www.w3schools.com/js/default.asp
// 2 - Javascript.com - https://www.javascript.com

//------------- 1. COMENTARIOS ------------------------

// para los comentarios, ponemos por delante dos barras "//"
// este es mi comentario

// comentarios multilinea
/*
    Este es mi 
    comentario multilinea
 */

//------------- 2. VARIABLES y MODIFICADORES DE ACCESO  ------------------------

// 2.1 VARIABLES

var x

x = 5

x = x + 5

// 2.2 MODIFICADORES DE ACCESO

// let
{
  let a = 2
  console.log(a)
}

// const
const PI = 3.141592653589793

//------------- 3. MODO ESTRICTO  ------------------------
var pais = 'Italia'
