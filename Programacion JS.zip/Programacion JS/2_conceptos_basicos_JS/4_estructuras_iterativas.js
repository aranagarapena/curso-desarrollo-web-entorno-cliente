//------------- 1. FOR ------------------------
// https://www.w3schools.com/js/js_loop_for.asp

var x = 10
for (let i = 0; i <= x; i++) {
  //   console.log('el numero actual del bucle FOR es: ' + i)
}

//------------- 2. WHILE ------------------------
// https://www.w3schools.com/js/js_loop_while.asp

var y = 0

while (y < 10) {
  //   console.log('el numero actual del bucle WHILE es: ' + y)
  y++
}

//------------- 3. DO/WHILE ------------------------
// https://www.w3schools.com/jsref/jsref_dowhile.asp

y = 0

do {
  console.log('el numero actual del bucle DO WHILE es: ' + y)
  y++
} while (y < 10)
